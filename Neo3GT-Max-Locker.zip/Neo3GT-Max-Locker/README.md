# Neo3GT Max Locker (ZTE nubia Neo 3 GT 5G — Unisoc T9100)

Proyek aplikasi Android siap kompilasi untuk mengunci frekuensi CPU (3-Cluster) dan GPU Mali-G57 tertinggi pada **ZTE nubia Neo 3 GT 5G (Unisoc T9100 / Android 15)**.

## Cara 1: Compile Jadi File `.apk` Otomatis via GitHub Actions (Tanpa PC / Android Studio)
1. Buat repository baru di GitHub (boleh Private atau Public).
2. Ekstrak seluruh isi file ZIP ini dan upload ke repository tersebut.
3. Buka tab **Actions** di repository GitHub Anda, pilih workflow **Build Neo3GT Max Locker APK**, lalu klik **Run workflow**.
4. Tunggu ~2 menit hingga selesai, lalu unduh **`Neo3GT-Max-Locker-debug`** di bagian **Artifacts** yang berisi file `app-debug.apk`.

## Cara 2: Compile Langsung di Android Studio / CLI
1. Buka folder `Neo3GT-Max-Locker` di **Android Studio**.
2. Tunggu Gradle sync selesai, lalu klik **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Atau lewat terminal: `gradle assembleDebug` (file hasil berada di `app/build/outputs/apk/debug/app-debug.apk`).
