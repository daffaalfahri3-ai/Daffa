package id.nubia.neo3gt.clocklocker

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val shizukuPermissionListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        try {
            Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        } catch (_: Exception) {
        }

        setContent {
            Neo3GTLockerScreen(
                onToggleLock = { enable ->
                    val serviceIntent = Intent(this, LockKeepAliveService::class.java)
                    if (enable) {
                        startForegroundService(serviceIntent)
                    } else {
                        stopService(serviceIntent)
                    }
                },
                onRequestShizuku = {
                    try {
                        if (Shizuku.pingBinder() &&
                            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED
                        ) {
                            Shizuku.requestPermission(102)
                        }
                    } catch (_: Exception) {
                    }
                }
            )
        }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}

@Composable
fun Neo3GTLockerScreen(
    onToggleLock: (Boolean) -> Unit,
    onRequestShizuku: () -> Unit
) {
    var isLocked by remember { mutableStateOf(false) }
    var telemetry by remember {
        mutableStateOf(HardwareTelemetry(0, 0, 0, 0, 0f, false))
    }
    var shizukuReady by remember { mutableStateOf(false) }

    // Polling telemetry setiap 1 detik
    LaunchedEffect(Unit) {
        while (true) {
            telemetry = withContext(Dispatchers.IO) {
                T9100LockEngine.readTelemetry()
            }
            shizukuReady = T9100LockEngine.isShizukuGranted()
            delay(1000L)
        }
    }

    val bgDark = Color(0xFF0B0E14)
    val cardDark = Color(0xFF151B26)
    val accentCyan = Color(0xFF00F0FF)
    val accentRed = Color(0xFFFF2A55)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bgDark)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = "NUBIA NEO 3 GT 5G",
                color = accentCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Text(
                text = "UNISOC T9100 MAX LOCKER",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Badge Status Akses Sistem
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusBadge(
                    label = if (telemetry.isRooted) "ROOT: GRANTED" else "ROOT: NOT FOUND",
                    active = telemetry.isRooted
                )
                StatusBadge(
                    label = if (shizukuReady) "SHIZUKU: READY" else "SHIZUKU: TAP TO AUTH",
                    active = shizukuReady,
                    onClick = onRequestShizuku
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Kartu Telemetry Real-Time
            Card(
                colors = CardDefaults.cardColors(containerColor = cardDark),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF263145), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    TelemetryRow("CPU Prime (1x A76 @ 2.7GHz)", "${telemetry.policy7Mhz} MHz")
                    HorizontalDivider(color = Color(0xFF232C3D), modifier = Modifier.padding(vertical = 10.dp))
                    TelemetryRow("CPU Perf (3x A76 @ 2.3GHz)", "${telemetry.policy4Mhz} MHz")
                    HorizontalDivider(color = Color(0xFF232C3D), modifier = Modifier.padding(vertical = 10.dp))
                    TelemetryRow("CPU Eff (4x A55 @ 2.1GHz)", "${telemetry.policy0Mhz} MHz")
                    HorizontalDivider(color = Color(0xFF232C3D), modifier = Modifier.padding(vertical = 10.dp))
                    TelemetryRow("GPU Mali-G57 Clock", "${telemetry.gpuMhz} MHz")
                    HorizontalDivider(color = Color(0xFF232C3D), modifier = Modifier.padding(vertical = 10.dp))
                    TelemetryRow(
                        "SoC Thermal",
                        String.format(Locale.US, "%.1f °C", telemetry.socTempC)
                    )
                }
            }
        }

        Column {
            if (!telemetry.isRooted) {
                Text(
                    text = if (shizukuReady) {
                        "Mode Shizuku aktif: Mengaktifkan Android Fixed Performance Mode. Untuk mengunci clock sysfs GPU/CPU secara penuh, gunakan Root (KernelSU / Magisk)."
                    } else {
                        "Catatan: Tanpa akses Root (KernelSU/Magisk), SELinux Android 15 membatasi penulisan langsung ke /sys/devices/system/cpu. Berikan akses Root atau aktifkan Shizuku."
                    },
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            Button(
                onClick = {
                    val nextState = !isLocked
                    isLocked = nextState
                    onToggleLock(nextState)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isLocked) accentRed else accentCyan,
                    contentColor = if (isLocked) Color.White else Color.Black
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(
                    text = if (isLocked) "UNLOCK & RESTORE STOCK" else "LOCK MAX CPU & GPU",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
fun StatusBadge(label: String, active: Boolean, onClick: (() -> Unit)? = null) {
    val color = if (active) Color(0xFF10B981) else Color(0xFF64748B)
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
            .border(1.dp, color, RoundedCornerShape(6.dp))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text = label, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TelemetryRow(title: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, color = Color(0xFFCBD5E1), fontSize = 13.sp)
        Text(text = value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
