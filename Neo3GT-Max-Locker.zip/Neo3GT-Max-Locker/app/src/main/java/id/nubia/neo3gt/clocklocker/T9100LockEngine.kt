package id.nubia.neo3gt.clocklocker

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.DataOutputStream
import java.io.File

data class HardwareTelemetry(
    val policy0Mhz: Int,
    val policy4Mhz: Int,
    val policy7Mhz: Int,
    val gpuMhz: Int,
    val socTempC: Float,
    val isRooted: Boolean
)

object T9100LockEngine {

    // Topologi 3-Cluster CPU Unisoc T9100 (ZTE nubia Neo 3 GT 5G)
    private val CPU_POLICIES = listOf(
        "/sys/devices/system/cpu/cpufreq/policy0", // 4x Cortex-A55 (Max 2.10 GHz)
        "/sys/devices/system/cpu/cpufreq/policy4", // 3x Cortex-A76 (Max 2.30 GHz)
        "/sys/devices/system/cpu/cpufreq/policy7"  // 1x Cortex-A76 Prime (Max 2.70 GHz)
    )

    fun hasRootAccess(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    fun isShizukuGranted(): Boolean {
        return try {
            Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    fun executeRootCommands(commands: List<String>): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            for (cmd in commands) {
                os.writeBytes("$cmd\n")
            }
            os.writeBytes("exit\n")
            os.flush()
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    private fun executeShizukuShellCommand(command: String): Boolean {
        return try {
            if (!isShizukuGranted()) return false
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as Process
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    private fun findUnisocGpuDevfreqPath(): String? {
        val devfreqDir = File("/sys/class/devfreq")
        if (!devfreqDir.exists()) return null
        val target = devfreqDir.listFiles()?.firstOrNull { file ->
            val name = file.name.lowercase()
            name.contains("gpu") || name.contains("mali")
        }
        return target?.absolutePath
    }

    /**
     * Mengunci CPU (3 Cluster) & GPU Mali-G57 ke frekuensi tertinggi
     */
    fun applyMaxPerformanceLock(): Boolean {
        if (!hasRootAccess()) {
            // Mode fallback Non-Root via Shizuku: aktifkan Fixed Performance Mode Android 15
            return executeShizukuShellCommand("cmd power set-fixed-performance-mode-enabled true")
        }

        val cmds = mutableListOf<String>()

        // 1. Aktifkan Android 15 Fixed Performance Mode
        cmds.add("cmd power set-fixed-performance-mode-enabled true")

        // 2. Lock seluruh cluster CPU Unisoc T9100
        for (policy in CPU_POLICIES) {
            cmds.add("""
                if [ -d "$policy" ]; then
                    MAX_FREQ=$(cat $policy/cpuinfo_max_freq)
                    chmod 0644 $policy/scaling_governor $policy/scaling_min_freq $policy/scaling_max_freq 2>/dev/null
                    echo "performance" > $policy/scaling_governor
                    echo "${'$'}MAX_FREQ" > $policy/scaling_max_freq
                    echo "${'$'}MAX_FREQ" > $policy/scaling_min_freq
                    chmod 0444 $policy/scaling_governor $policy/scaling_min_freq $policy/scaling_max_freq 2>/dev/null
                fi
            """.trimIndent())
        }

        // 3. Lock GPU Mali-G57 melalui node devfreq Unisoc
        val gpuPath = findUnisocGpuDevfreqPath() ?: "/sys/class/devfreq/23000000.gpu"
        cmds.add("""
            GPU_DIR="$gpuPath"
            if [ ! -d "${'$'}GPU_DIR" ]; then
                GPU_DIR=$(ls -d /sys/class/devfreq/*mali* /sys/class/devfreq/*gpu* 2>/dev/null | head -n 1)
            fi
            if [ -n "${'$'}GPU_DIR" ] && [ -d "${'$'}GPU_DIR" ]; then
                GPU_MAX=$(tr ' ' '\n' < "${'$'}GPU_DIR/available_frequencies" | sort -nr | head -n 1)
                if [ -z "${'$'}GPU_MAX" ]; then
                    GPU_MAX=$(cat "${'$'}GPU_DIR/max_freq")
                fi
                chmod 0644 "${'$'}GPU_DIR/governor" "${'$'}GPU_DIR/min_freq" "${'$'}GPU_DIR/max_freq" 2>/dev/null
                echo "performance" > "${'$'}GPU_DIR/governor" 2>/dev/null
                echo "${'$'}GPU_MAX" > "${'$'}GPU_DIR/max_freq"
                echo "${'$'}GPU_MAX" > "${'$'}GPU_DIR/min_freq"
                chmod 0444 "${'$'}GPU_DIR/governor" "${'$'}GPU_DIR/min_freq" "${'$'}GPU_DIR/max_freq" 2>/dev/null
            fi
        """.trimIndent())

        return executeRootCommands(cmds)
    }

    /**
     * Mengembalikan konfigurasi CPU & GPU ke mode normal (schedutil / simple_ondemand)
     */
    fun restoreStockClocks(): Boolean {
        if (!hasRootAccess()) {
            return executeShizukuShellCommand("cmd power set-fixed-performance-mode-enabled false")
        }

        val cmds = mutableListOf<String>()
        cmds.add("cmd power set-fixed-performance-mode-enabled false")

        for (policy in CPU_POLICIES) {
            cmds.add("""
                if [ -d "$policy" ]; then
                    MIN_FREQ=$(cat $policy/cpuinfo_min_freq)
                    MAX_FREQ=$(cat $policy/cpuinfo_max_freq)
                    chmod 0644 $policy/scaling_governor $policy/scaling_min_freq $policy/scaling_max_freq 2>/dev/null
                    echo "schedutil" > $policy/scaling_governor
                    echo "${'$'}MIN_FREQ" > $policy/scaling_min_freq
                    echo "${'$'}MAX_FREQ" > $policy/scaling_max_freq
                fi
            """.trimIndent())
        }

        cmds.add("""
            GPU_DIR=$(ls -d /sys/class/devfreq/*mali* /sys/class/devfreq/*gpu* 2>/dev/null | head -n 1)
            if [ -n "${'$'}GPU_DIR" ] && [ -d "${'$'}GPU_DIR" ]; then
                GPU_MIN=$(tr ' ' '\n' < "${'$'}GPU_DIR/available_frequencies" | sort -n | grep -v '^$' | head -n 1)
                GPU_MAX=$(tr ' ' '\n' < "${'$'}GPU_DIR/available_frequencies" | sort -nr | head -n 1)
                chmod 0644 "${'$'}GPU_DIR/governor" "${'$'}GPU_DIR/min_freq" "${'$'}GPU_DIR/max_freq" 2>/dev/null
                echo "simple_ondemand" > "${'$'}GPU_DIR/governor" 2>/dev/null
                echo "${'$'}GPU_MIN" > "${'$'}GPU_DIR/min_freq"
                echo "${'$'}GPU_MAX" > "${'$'}GPU_DIR/max_freq"
            fi
        """.trimIndent())

        return executeRootCommands(cmds)
    }

    /**
     * Membaca frekuensi real-time CPU, GPU, dan suhu SoC
     */
    fun readTelemetry(): HardwareTelemetry {
        fun readKhzToMhz(path: String): Int {
            return try {
                File(path).readText().trim().toInt() / 1000
            } catch (e: Exception) {
                0
            }
        }

        val p0 = readKhzToMhz("/sys/devices/system/cpu/cpufreq/policy0/scaling_cur_freq")
        val p4 = readKhzToMhz("/sys/devices/system/cpu/cpufreq/policy4/scaling_cur_freq")
        val p7 = readKhzToMhz("/sys/devices/system/cpu/cpufreq/policy7/scaling_cur_freq")

        val gpuMhz = try {
            val gpuDir = findUnisocGpuDevfreqPath()
            if (gpuDir != null) {
                val raw = File("$gpuDir/cur_freq").readText().trim().toLong()
                if (raw > 10_000_000L) raw / 1_000_000L else raw / 1_000L
            } else 0L
        } catch (e: Exception) {
            0L
        }.toInt()

        val tempC = try {
            val zones = listOf(
                "/sys/class/thermal/thermal_zone0/temp",
                "/sys/class/thermal/thermal_zone1/temp",
                "/sys/class/thermal/thermal_zone2/temp"
            )
            var foundTemp = 0f
            for (z in zones) {
                val f = File(z)
                if (f.exists()) {
                    val rawTemp = f.readText().trim().toFloat()
                    val parsed = if (rawTemp > 1000f) rawTemp / 1000f else rawTemp
                    if (parsed in 15f..115f) {
                        foundTemp = parsed
                        break
                    }
                }
            }
            foundTemp
        } catch (e: Exception) {
            0f
        }

        return HardwareTelemetry(
            policy0Mhz = p0,
            policy4Mhz = p4,
            policy7Mhz = p7,
            gpuMhz = gpuMhz,
            socTempC = tempC,
            isRooted = hasRootAccess()
        )
    }
}
