package id.nubia.neo3gt.clocklocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.*

class LockKeepAliveService : Service() {

    companion object {
        const val ACTION_STOP_LOCK = "id.nubia.neo3gt.clocklocker.ACTION_STOP_LOCK"
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var watchdogJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_LOCK) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(101, buildNotification())

        watchdogJob?.cancel()
        watchdogJob = serviceScope.launch {
            while (isActive) {
                T9100LockEngine.applyMaxPerformanceLock()
                delay(3000L) // Verifikasi ulang setiap 3 detik melawan thermal/Game Space reset
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        watchdogJob?.cancel()
        serviceScope.cancel()
        T9100LockEngine.restoreStockClocks()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "neo3gt_lock_channel"
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            channelId,
            "Neo3GT Max Clock Lock",
            NotificationManager.IMPORTANCE_LOW
        )
        manager.createNotificationChannel(channel)

        val stopIntent = Intent(this, LockKeepAliveService::class.java).apply {
            action = ACTION_STOP_LOCK
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            0,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, channelId)
            .setContentTitle("Unisoc T9100 MAX LOCK Aktif")
            .setContentText("CPU 2.70 GHz & GPU Mali-G57 dikunci pada performa tertinggi")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    null,
                    "UNLOCK",
                    stopPendingIntent
                ).build()
            )
            .build()
    }
}
