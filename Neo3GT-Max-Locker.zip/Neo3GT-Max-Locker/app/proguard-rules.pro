# ProGuard rules for Neo3GT Max Locker
-keep class rikka.shizuku.** { *; }
